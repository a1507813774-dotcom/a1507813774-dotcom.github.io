package com.onec.audio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.content.SharedPreferences;
import android.util.Log;

import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kotlin.Unit;
import kotlin.jvm.functions.Function3;

public class AudioService extends Service {
    public static final String ACTION_DOWNLOAD = "com.onec.audio.DOWNLOAD";
    public static final String ACTION_CANCEL = "com.onec.audio.CANCEL";
    public static final String ACTION_STATUS = "com.onec.audio.STATUS";
    public static final String KEY_URL = "url";
    public static final String KEY_TEXT = "text";
    public static final String KEY_PROGRESS = "progress";
    public static final String KEY_BUSY = "busy";
    public static final String KEY_FILE_URI = "file_uri";
    public static final String KEY_LOG = "full_error_log";
    private static final String PREFS = "engine_settings";
    private static final long UPDATE_INTERVAL = 3L * 24L * 60L * 60L * 1000L;
    private static final String CHANNEL = "audio_downloads";
    private static final int NOTIFICATION_ID = 1099;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean busy = false;
    private volatile boolean cancelled = false;
    private volatile String processId = "";
    private volatile long lastUpdateMs = 0;
    private volatile int lastProgress = 0;
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(new NotificationChannel(CHANNEL,
                "音频下载进度", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_CANCEL.equals(intent.getAction())) {
            if (busy) {
                cancelled = true;
                try { YoutubeDL.getInstance().destroyProcessById(processId); }
                catch (Exception ignored) { }
                status("正在取消…", lastProgress, true, null);
            }
            return START_NOT_STICKY;
        }
        if (!ACTION_DOWNLOAD.equals(intent.getAction())) return START_NOT_STICKY;
        if (busy) {
            status("已有下载任务，请等待完成", lastProgress, true, null);
            return START_NOT_STICKY;
        }
        final String url = intent.getStringExtra(KEY_URL);
        if (url == null || url.isEmpty()) return START_NOT_STICKY;
        busy = true;
        cancelled = false;
        lastProgress = 0;
        processId = "audio-" + SystemClock.elapsedRealtime();
        startForeground(NOTIFICATION_ID, notification("正在准备下载", 0, true));
        status("正在解析视频并提取音频…", 0, true, null);
        worker.execute(() -> doDownload(url, startId));
        return START_NOT_STICKY;
    }

    private void doDownload(String url, int startId) {
        File taskDir = new File(getCacheDir(), "task_" + SystemClock.elapsedRealtime());
        taskDir.mkdirs();
        try {
            YoutubeDL.getInstance().init(getApplicationContext());
            if (cancelled) throw new InterruptedException("用户已取消");
            tryUpdateEngine();
            if (cancelled) throw new InterruptedException("用户已取消");
            YoutubeDLRequest request = new YoutubeDLRequest(url);
            request.addOption("--no-playlist");
            request.addOption("--windows-filenames");
            request.addOption("--no-mtime");
            request.addOption("--remote-components", "ejs:github");
            request.addOption("--socket-timeout", "20");
            request.addOption("--retries", "3");
            request.addOption("--fragment-retries", "3");
            // yt-dlp supports both YouTube and Bilibili (including b23.tv redirects).
            // Never fall back to a video-containing format.
            request.addOption("-f", "bestaudio[ext=m4a]/bestaudio");
            request.addOption("-o", new File(taskDir, "%(title).110B [%(id)s].%(ext)s").getAbsolutePath());
            // First download an audio-only source. Then encode offline to 32kbps AAC.
            final Function3<Float, Long, String, Unit> cb = (percent, eta, line) -> {
                if (cancelled) return Unit.INSTANCE;
                int p = Math.max(0, Math.min(75, Math.round(percent * 0.75f)));
                long now = SystemClock.elapsedRealtime();
                if (p != lastProgress || now - lastUpdateMs > 1500) {
                    lastProgress = p;
                    lastUpdateMs = now;
                    status(String.format(Locale.CHINA, "正在下载原始音轨：%d%%", p), p, true, null);
                }
                return Unit.INSTANCE;
            };
            YoutubeDL.getInstance().execute(request, processId, cb);
            if (cancelled) throw new InterruptedException("用户已取消");
            File file = findAudio(taskDir);
            if (file == null) throw new IllegalStateException("未找到生成的音频文件");
            status("下载完成，正在压缩为 32 kbps AAC…", 76, true, null);
            String base = file.getName();
            int ext = base.lastIndexOf('.');
            if (ext > 0) base = base.substring(0, ext);
            if (base.length() > 130) base = base.substring(0, 130);
            File compressed = new File(taskDir, base + " [32kbps].m4a");
            File result = AudioTranscoder.convert(file, compressed, progress -> {
                if (cancelled) throw new InterruptedException("用户已取消");
                if (progress > lastProgress) {
                    lastProgress = progress;
                    status(String.format(Locale.CHINA, "正在压缩音频至 32 kbps：%d%%", progress),
                            progress, true, null);
                }
            });
            if (cancelled) throw new InterruptedException("用户已取消");
            status("正在保存 32 kbps 音频到下载目录…", 98, true, null);
            Uri saved = saveToDownloads(result);
            getSharedPreferences("last_download", MODE_PRIVATE).edit()
                    .putString("uri", saved.toString())
                    .putString("name", result.getName()).apply();
            status("下载完成 · 32 kbps · 下载/音频直取/" + result.getName(), 100, false, saved);
            notificationManager.notify(NOTIFICATION_ID, notification("音频已保存到下载目录", 100, false));
        } catch (Exception e) {
            String raw = e.getMessage() == null ? e.toString() : e.getMessage();
            String detail = cancelled ? "下载已取消" : "下载失败：" + usefulMessage(raw);
            Log.e("AudioOneTap", "Download error", e);
            status(detail, 0, false, null, raw);
            notificationManager.notify(NOTIFICATION_ID, notification(detail, 0, false));
        } finally {
            clean(taskDir);
            busy = false;
            cancelled = false;
            stopForeground(STOP_FOREGROUND_DETACH);
            stopSelfResult(startId);
        }
    }

    private void tryUpdateEngine() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        long previous = prefs.getLong("last_check_time", 0L);
        long now = System.currentTimeMillis();
        // 每三天最多检查一次。失败时保留 APK 中的官方内置版本。
        if (previous > 0 && now - previous < UPDATE_INTERVAL) return;
        status("正在检查最新下载引擎（首次使用可能稍慢）…", 0, true, null);
        try {
            YoutubeDL.getInstance().updateYoutubeDL(getApplicationContext(), YoutubeDL.UpdateChannel.STABLE.INSTANCE);
            prefs.edit().putLong("last_check_time", now).apply();
        } catch (Exception updateError) {
            // 更新失败不应阻止尝试本地已经打包的 yt-dlp。
            Log.w("AudioOneTap", "Engine update skipped; using bundled version", updateError);
            prefs.edit().putLong("last_check_time", now).apply();
        }
    }

    private String usefulMessage(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "下载引擎未返回具体原因";
        String[] lines = raw.replace('\r', '\n').split("\n");
        String best = "";
        String fallback = "";
        for (String line : lines) {
            String t = line.trim();
            if (t.isEmpty()) continue;
            if (t.contains("ERROR:") || t.contains("Traceback") || t.contains("HTTP Error") ||
                    t.contains("Sign in to confirm") || t.contains("Requested format is not available")) best = t;
            if (!t.toUpperCase(Locale.ROOT).startsWith("WARNING:") && !t.startsWith("[debug]")) fallback = t;
        }
        String message = best.isEmpty() ? fallback : best;
        if (message.isEmpty()) message = lines[lines.length-1].trim();
        if (message.contains("HTTP Error 403"))
            message += "（可能为 YouTube 验证限制）";
        return message.length() > 420 ? message.substring(0, 420) + "…" : message;
    }

    private File findAudio(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) {
            if (!f.isFile()) continue;
            String n = f.getName().toLowerCase(Locale.ROOT);
            if ((n.endsWith(".m4a") || n.endsWith(".webm") || n.endsWith(".opus")
                    || n.endsWith(".mp3") || n.endsWith(".ogg")) && f.length() > 0) return f;
        }
        return null;
    }

    private Uri saveToDownloads(File audio) throws Exception {
        final String name = audio.getName().length() > 185
                ? audio.getName().substring(0, 168) + audio.getName().substring(audio.getName().lastIndexOf('.'))
                : audio.getName();
        final String lower = name.toLowerCase(Locale.ROOT);
        final String mime = lower.endsWith(".m4a") ? "audio/mp4"
                : lower.endsWith(".mp3") ? "audio/mpeg"
                : lower.endsWith(".opus") ? "audio/ogg"
                : lower.endsWith(".ogg") ? "audio/ogg" : "audio/webm";
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/音频直取/");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("无法创建下载文件");
        try {
            try (FileInputStream input = new FileInputStream(audio);
                 OutputStream output = resolver.openOutputStream(uri)) {
                if (output == null) throw new IllegalStateException("无法写入下载文件");
                byte[] buffer = new byte[65536];
                int count;
                while ((count = input.read(buffer)) >= 0) {
                    if (cancelled) throw new InterruptedException("用户已取消");
                    output.write(buffer, 0, count);
                }
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            if (resolver.update(uri, done, null, null) <= 0)
                throw new IllegalStateException("文件保存后无法完成公开发布");
            // Check the published URI actually resolves to a nonempty file.
            try (android.os.ParcelFileDescriptor fd = resolver.openFileDescriptor(uri, "r")) {
                if (fd == null || fd.getStatSize() == 0)
                    throw new IllegalStateException("已写入的音频无法再次读取");
            }
            return uri;
        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }
    }

    private Notification notification(String text, int progress, boolean ongoing) {
        Intent activity = new Intent(this, MainActivity.class);
        activity.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(this, 0, activity,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("音频直取")
                .setContentText(text)
                .setContentIntent(tap)
                .setOnlyAlertOnce(true)
                .setOngoing(ongoing);
        if (ongoing) n.setProgress(100, progress, progress == 0);
        else n.setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true);
        return n.build();
    }

    private void status(String text, int progress, boolean isBusy, Uri fileUri) {
        status(text, progress, isBusy, fileUri, null);
    }

    private void status(String text, int progress, boolean isBusy, Uri fileUri, String log) {
        Intent broadcast = new Intent(ACTION_STATUS).setPackage(getPackageName());
        if (log != null) broadcast.putExtra(KEY_LOG, log.length() > 12000 ? log.substring(log.length() - 12000) : log);
        broadcast.putExtra(KEY_TEXT, text);
        broadcast.putExtra(KEY_PROGRESS, progress);
        broadcast.putExtra(KEY_BUSY, isBusy);
        if (fileUri != null) broadcast.putExtra(KEY_FILE_URI, fileUri.toString());
        sendBroadcast(broadcast);
        if (isBusy) notificationManager.notify(NOTIFICATION_ID, notification(text, progress, true));
    }

    private void clean(File dir) {
        File[] children = dir.listFiles();
        if (children != null) for (File c : children) { if (c.isDirectory()) clean(c); else c.delete(); }
        dir.delete();
    }

    @Override public void onDestroy() { worker.shutdown(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
