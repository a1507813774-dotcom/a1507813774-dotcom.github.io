package com.onec.audio;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.content.ContentResolver;
import android.provider.DocumentsContract;
import android.os.ParcelFileDescriptor;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity {
    private static final int BG = Color.rgb(11, 17, 34);
    private static final int CARD = Color.rgb(23, 34, 55);
    private static final int TEXT = Color.rgb(240, 247, 253);
    private static final int MUTED = Color.rgb(155, 172, 192);
    private static final int MINT = Color.rgb(66, 231, 183);
    private EditText input;
    private TextView status;
    private ProgressBar bar;
    private Button download;
    private Button cancel;
    private Button openFile;
    private Button shareFile;
    private Button browseFiles;
    private Button copyError;
    private String lastErrorLog = "";
    private String latestUri;
    private boolean busy = false;
    private final BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            status.setText(intent.getStringExtra(AudioService.KEY_TEXT));
            bar.setProgress(intent.getIntExtra(AudioService.KEY_PROGRESS, 0));
            setBusy(intent.getBooleanExtra(AudioService.KEY_BUSY, false));
            String uri = intent.getStringExtra(AudioService.KEY_FILE_URI);
            if (uri != null) {
                latestUri = uri;
                openFile.setVisibility(View.VISIBLE);
                shareFile.setVisibility(View.VISIBLE);
            }
            String errorLog = intent.getStringExtra(AudioService.KEY_LOG);
            if (errorLog != null) {
                lastErrorLog = errorLog;
                copyError.setVisibility(View.VISIBLE);
            }
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
        restoreLastFile();
        handleIncoming(getIntent());
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    @Override protected void onStart() {
        super.onStart();
        registerReceiver(updateReceiver, new IntentFilter(AudioService.ACTION_STATUS), Context.RECEIVER_NOT_EXPORTED);
        restoreLastFile();
    }
    @Override protected void onStop() { unregisterReceiver(updateReceiver); super.onStop(); }

    private void handleIncoming(Intent intent) {
        if (intent == null) return;
        String link = null;
        if (Intent.ACTION_SEND.equals(intent.getAction())) link = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null)
            link = intent.getData().toString();
        if (link != null) {
            String url = LinkParser.extract(link);
            input.setText(url == null ? link : url);
            // 从分享菜单打开时，只有可信来源链接才自动开始下载。
            if (url != null) input.post(() -> startDownload(url));
        }
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(24), dp(54), dp(24), dp(30));
        scroll.addView(outer);

        TextView insignia = label("♫  ↓", 39, MINT, Typeface.BOLD);
        insignia.setGravity(Gravity.CENTER);
        insignia.setBackground(gradient(Color.rgb(30, 89, 100), Color.rgb(15, 50, 79), 26));
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(88), dp(88));
        logoParams.bottomMargin = dp(24);
        outer.addView(insignia, logoParams);
        outer.addView(label("音频直取 · 1.3", 30, TEXT, Typeface.BOLD));
        TextView subheading = label("提取音轨，自动压缩至 32 kbps。", 15, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(10);
        outer.addView(subheading, subParams);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(22), dp(18), dp(22));
        panel.setBackground(shape(CARD, 25));
        LinearLayout.LayoutParams panelParams = new LinearLayout.LayoutParams(-1, -2);
        panelParams.topMargin = dp(36);
        outer.addView(panel, panelParams);
        panel.addView(label("YouTube / Bilibili 分享链接", 15, TEXT, Typeface.BOLD));
        input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(2);
        input.setMaxLines(4);
        input.setTextSize(15);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("直接粘贴完整分享文案（包含中文介绍也可以）…");
        input.setBackground(shape(Color.rgb(13, 23, 42), 15));
        input.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, -2);
        inputParams.topMargin = dp(16);
        panel.addView(input, inputParams);

        Button paste = button("粘贴剪贴板", Color.rgb(44, 63, 83), TEXT);
        LinearLayout.LayoutParams pasteParams = new LinearLayout.LayoutParams(-1, dp(46));
        pasteParams.topMargin = dp(12);
        panel.addView(paste, pasteParams);
        paste.setOnClickListener(v -> pasteClipboard());

        download = button("↓   一键下载纯音频", MINT, Color.rgb(9, 30, 37));
        LinearLayout.LayoutParams downloadParams = new LinearLayout.LayoutParams(-1, dp(58));
        downloadParams.topMargin = dp(21);
        panel.addView(download, downloadParams);
        download.setOnClickListener(v -> startDownload(input.getText().toString().trim()));

        cancel = button("取消下载", Color.rgb(83, 45, 56), TEXT);
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-1, dp(46));
        cancelParams.topMargin = dp(10);
        panel.addView(cancel, cancelParams);
        cancel.setVisibility(View.GONE);
        cancel.setOnClickListener(v -> startService(new Intent(this, AudioService.class).setAction(AudioService.ACTION_CANCEL)));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT));
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, dp(6));
        barParams.topMargin = dp(25);
        panel.addView(bar, barParams);
        status = label("准备就绪 · 输出 32 kbps AAC 音频", 13, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(15);
        panel.addView(status, statusParams);
        openFile = button("打开已下载文件", Color.rgb(38, 74, 68), TEXT);
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(-1, dp(48));
        openParams.topMargin = dp(14);
        panel.addView(openFile, openParams);
        openFile.setVisibility(View.GONE);
        openFile.setOnClickListener(v -> openDownloaded());
        shareFile = button("分享音频到 Drive / 其他应用", Color.rgb(38, 74, 68), TEXT);
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(-1, dp(48));
        shareParams.topMargin = dp(10);
        panel.addView(shareFile, shareParams);
        shareFile.setVisibility(View.GONE);
        shareFile.setOnClickListener(v -> shareDownloaded());
        browseFiles = button("浏览下载目录", Color.rgb(44, 63, 83), TEXT);
        LinearLayout.LayoutParams browseParams = new LinearLayout.LayoutParams(-1, dp(46));
        browseParams.topMargin = dp(10);
        panel.addView(browseFiles, browseParams);
        browseFiles.setOnClickListener(v -> browseDownloadFolder());
        copyError = button("复制详细错误日志", Color.rgb(63, 69, 89), TEXT);
        LinearLayout.LayoutParams errorParams = new LinearLayout.LayoutParams(-1, dp(46));
        errorParams.topMargin = dp(10);
        panel.addView(copyError, errorParams);
        copyError.setVisibility(View.GONE);
        copyError.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("音频直取错误日志", lastErrorLog));
            Toast.makeText(this, "已复制完整错误日志", Toast.LENGTH_SHORT).show();
        });

        TextView hint = label("📂 保存位置：下载 / 音频直取\n\n• 默认 32 kbps AAC（单声道 M4A，适合讲话）\n• 下载后在本机压缩，不上传音频\n• 支持 YouTube「分享」→「音频直取」\n• 无广告 · 无账号 · 不读取其他文件", 13, MUTED, Typeface.NORMAL);
        hint.setLineSpacing(dp(3), 1.2f);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(30);
        outer.addView(hint, hintParams);
        setContentView(scroll);
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip().getItemCount() == 0) {
            Toast.makeText(this, "剪贴板没有内容", Toast.LENGTH_SHORT).show();
            return;
        }
        CharSequence item = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
        String raw = item == null ? "" : item.toString();
        String url = LinkParser.extract(raw);
        input.setText(url == null ? raw : url);
        if (url != null && !raw.trim().equals(url))
            Toast.makeText(this, "已从分享文案提取视频链接", Toast.LENGTH_SHORT).show();
    }

    private void startDownload(String text) {
        if (busy) return;
        String url = LinkParser.extract(text);
        if (url == null) {
            input.setError("请粘贴 YouTube 或 Bilibili 视频分享链接");
            return;
        }
        input.setText(url);
        setBusy(true);
        latestUri = null;
        lastErrorLog = "";
        openFile.setVisibility(View.GONE);
        shareFile.setVisibility(View.GONE);
        copyError.setVisibility(View.GONE);
        status.setText("正在启动下载…");
        bar.setProgress(0);
        try {
            Intent service = new Intent(this, AudioService.class).setAction(AudioService.ACTION_DOWNLOAD);
            service.putExtra(AudioService.KEY_URL, url);
            startForegroundService(service);
        } catch (Exception e) {
            setBusy(false);
            status.setText("启动失败：" + e.getMessage());
        }
    }

    /** Retain the MediaStore URI, so reopening the app still exposes the audio file. */
    private void restoreLastFile() {
        if (busy) return;
        SharedPreferences prefs = getSharedPreferences("last_download", MODE_PRIVATE);
        String saved = prefs.getString("uri", null);
        if (saved == null || saved.isEmpty()) return;
        try (ParcelFileDescriptor descriptor = getContentResolver()
                .openFileDescriptor(Uri.parse(saved), "r")) {
            if (descriptor == null) return;
            latestUri = saved;
            openFile.setVisibility(View.VISIBLE);
            shareFile.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            prefs.edit().remove("uri").apply();
        }
    }

    private void shareDownloaded() {
        if (TextUtils.isEmpty(latestUri)) return;
        Uri uri = Uri.parse(latestUri);
        try {
            String type = getContentResolver().getType(uri);
            if (type == null || !type.startsWith("audio/")) type = "audio/*";
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(type);
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.setClipData(ClipData.newUri(getContentResolver(), "已下载音频", uri));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "分享音频文件"));
        } catch (Exception e) {
            Toast.makeText(this, "分享失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Launch the system's file picker with a hint for our actual Downloads directory. */
    private void browseDownloadFolder() {
        try {
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("audio/*");
            Uri folder = DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", "primary:Download/音频直取");
            picker.putExtra(DocumentsContract.EXTRA_INITIAL_URI, folder);
            startActivity(picker);
        } catch (Exception e) {
            Toast.makeText(this, "请在文件管理器中进入 下载/音频直取", Toast.LENGTH_LONG).show();
        }
    }

    private void setBusy(boolean value) {
        busy = value;
        download.setEnabled(!value);
        download.setAlpha(value ? 0.5f : 1f);
        cancel.setVisibility(value ? View.VISIBLE : View.GONE);
    }

    private void openDownloaded() {
        if (TextUtils.isEmpty(latestUri)) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(latestUri));
            i.setDataAndType(Uri.parse(latestUri), "audio/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "打开音频"));
        } catch (Exception e) { Toast.makeText(this, "请打开系统下载文件夹查看", Toast.LENGTH_LONG).show(); }
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String s, int size, int color, int style) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", style));
        return t;
    }
    private Button button(String s, int background, int foreground) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(15); b.setAllCaps(false); b.setTextColor(foreground);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(shape(background, 15));
        return b;
    }
    private GradientDrawable shape(int color, int corner) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color); drawable.setCornerRadius(dp(corner));
        return drawable;
    }
    private GradientDrawable gradient(int c1, int c2, int corner) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(corner)); return g;
    }
}
