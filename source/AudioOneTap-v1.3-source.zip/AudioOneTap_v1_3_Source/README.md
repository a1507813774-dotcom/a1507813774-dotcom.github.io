# 音频直取 v1.3 — Android 纯音频下载与 32 kbps 压缩

在 v1.2 基础上：

- 支持 YouTube、Bilibili（包括 b23.tv / bili2233.cn 短链），可从中文分享文案中抽取网址。
- **默认 32 kbps AAC-LC、单声道，输出 `.m4a`，适合讲座、播客、语音**。
- 先通过 yt-dlp **仅下载音频流**，随后通过 Android 原生 `MediaExtractor`、`MediaCodec`、`MediaMuxer` 在本机压缩。
- 压缩只能减小最终文件体积，不能保证减少网站到手机的下载流量；32 kbps 的音乐音质会明显下降。
- 文件保存在 `Download/音频直取/`，支持直接打开、Android 分享菜单发送到 Drive。
- 保留后台通知、进度、取消、错误日志、下载目录入口和最近文件 URI。

预计体积：32,000 bit/s ≈ 0.24 MB/min，10 分钟约 2.4 MB（不含少量容器开销）。

## 构建

Android Gradle Plugin 8.7.3, compileSdk 35, Gradle 8.11.1, Java 17。运行 `gradle :app:assembleDebug`。

无额外 ffmpeg 依赖；AAC 硬件/软件编码器与 Android MediaExtractor 对源格式的解码能力依赖设备。若设备无法解码，将报错，不会误将原音轨标记为 32 kbps。
