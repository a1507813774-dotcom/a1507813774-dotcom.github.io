package com.onec.audio;

import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import android.os.SystemClock;

/** Transcode downloaded speech audio to mono AAC-LC at 32,000 bits/second.
 * Uses Android's platform codecs; requires no FFmpeg binary or network upload.
 */
final class AudioTranscoder {
    static final int TARGET_BITRATE = 32_000;
    private static final long WAIT_US = 5_000;
    private static final long IDLE_LIMIT_MS = 20_000;
    private static final String AAC_MIME = "audio/mp4a-latm";

    interface Progress {
        void update(int percent) throws InterruptedException;
    }

    static File convert(File source, File target, Progress progress) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec decoder = null;
        MediaCodec encoder = null;
        MediaMuxer muxer = null;
        boolean muxerStarted = false;
        try {
            extractor.setDataSource(source.getAbsolutePath());
            MediaFormat inputFormat = null;
            int audioTrack = -1;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    inputFormat = format;
                    break;
                }
            }
            if (audioTrack < 0 || inputFormat == null)
                throw new IOException("视频来源未提供可解码的音频轨道");
            extractor.selectTrack(audioTrack);
            final String inputMime = inputFormat.getString(MediaFormat.KEY_MIME);
            if (inputMime == null) throw new IOException("无法识别输入音频格式");
            final int sourceRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            final long durationUs = inputFormat.containsKey(MediaFormat.KEY_DURATION)
                    ? inputFormat.getLong(MediaFormat.KEY_DURATION) : 0;
            if (sourceRate <= 0) throw new IOException("无效的音频采样率");

            decoder = MediaCodec.createDecoderByType(inputMime);
            decoder.configure(inputFormat, null, null, 0);
            decoder.start();

            MediaFormat outputFormat = MediaFormat.createAudioFormat(AAC_MIME, sourceRate, 1);
            outputFormat.setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            outputFormat.setInteger(MediaFormat.KEY_BIT_RATE, TARGET_BITRATE);
            outputFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024);
            encoder = MediaCodec.createEncoderByType(AAC_MIME);
            encoder.configure(outputFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();

            muxer = new MediaMuxer(target.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            MediaCodec.BufferInfo decoded = new MediaCodec.BufferInfo();
            MediaCodec.BufferInfo encoded = new MediaCodec.BufferInfo();
            boolean decoderInputEnded = false;
            boolean decoderOutputEnded = false;
            boolean encoderInputEnded = false;
            boolean encoderOutputEnded = false;
            ByteBuffer pendingMono = null;
            long samplesQueued = 0;
            int muxerTrack = -1;
            int lastProgress = -1;
            int channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            int pcmRate = sourceRate;
            long lastForwardMs = SystemClock.elapsedRealtime();

            while (!encoderOutputEnded) {
                // A buggy platform codec can return INFO_TRY_AGAIN_LATER forever.
                // Do not trap the user's downloaded audio behind an endless loop.
                if (Thread.currentThread().isInterrupted())
                    throw new InterruptedException("音频压缩已中断");
                if (SystemClock.elapsedRealtime() - lastForwardMs > IDLE_LIMIT_MS)
                    throw new IOException("压缩引擎超过 20 秒没有处理任何音频数据");

                // Never flood decoder inputs when a decoded chunk is waiting to be encoded.
                if (!decoderInputEnded && pendingMono == null) {
                    int i = decoder.dequeueInputBuffer(WAIT_US);
                    if (i >= 0) {
                        ByteBuffer b = decoder.getInputBuffer(i);
                        if (b == null) throw new IOException("解码器输入缓冲区不可用");
                        b.clear();
                        int size = extractor.readSampleData(b, 0);
                        if (size < 0) {
                            decoder.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            decoderInputEnded = true;
                        } else {
                            long pts = Math.max(0, extractor.getSampleTime());
                            decoder.queueInputBuffer(i, 0, size, pts, 0);
                            extractor.advance();
                            lastForwardMs = SystemClock.elapsedRealtime();
                            int pct = durationUs <= 0 ? 79 : 76 + (int) Math.min(14,
                                    (pts * 14L / durationUs));
                            if (pct > lastProgress) {
                                progress.update(pct);
                                lastProgress = pct;
                            }
                        }
                    }
                }

                // Flush the current PCM chunk into the AAC encoder, piece by piece.
                if (pendingMono != null && pendingMono.hasRemaining()) {
                    int i = encoder.dequeueInputBuffer(WAIT_US);
                    if (i >= 0) {
                        ByteBuffer b = encoder.getInputBuffer(i);
                        if (b == null) throw new IOException("编码器输入缓冲区不可用");
                        b.clear();
                        int size = Math.min(b.remaining(), pendingMono.remaining());
                        // AAC input is signed 16-bit mono PCM, aligned to sample boundaries.
                        size &= ~1;
                        if (size == 0)
                            throw new IOException("AAC 编码器输入缓冲区容量不足");
                        if (size > 0) {
                            int originalLimit = pendingMono.limit();
                            pendingMono.limit(pendingMono.position() + size);
                            b.put(pendingMono);
                            pendingMono.limit(originalLimit);
                            long pts = samplesQueued * 1_000_000L / pcmRate;
                            encoder.queueInputBuffer(i, 0, size, pts, 0);
                            samplesQueued += size / 2;
                            lastForwardMs = SystemClock.elapsedRealtime();
                        }
                    }
                }
                if (pendingMono != null && !pendingMono.hasRemaining()) pendingMono = null;

                // Consume decoded PCM only after the previous chunk has been submitted.
                if (pendingMono == null && !decoderOutputEnded) {
                    int o = decoder.dequeueOutputBuffer(decoded, WAIT_US);
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat format = decoder.getOutputFormat();
                        channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        int actualRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        if (actualRate != sourceRate)
                            throw new IOException("音轨采样率在解码过程中发生变化，无法安全转码");
                        if (format.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                                format.getInteger(MediaFormat.KEY_PCM_ENCODING) != AudioFormat.ENCODING_PCM_16BIT)
                            throw new IOException("输入音频解码器未输出 16 位 PCM");
                    } else if (o >= 0) {
                        ByteBuffer buffer = decoder.getOutputBuffer(o);
                        if (decoded.size > 0) {
                            if (buffer == null) throw new IOException("解码后的音频不可读取");
                            buffer.position(decoded.offset);
                            buffer.limit(decoded.offset + decoded.size);
                            pendingMono = downmixToMono(buffer, channels);
                            lastForwardMs = SystemClock.elapsedRealtime();
                        }
                        boolean eos = (decoded.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                        decoder.releaseOutputBuffer(o, false);
                        if (eos) decoderOutputEnded = true;
                    }
                }

                if (decoderOutputEnded && pendingMono == null && !encoderInputEnded) {
                    int i = encoder.dequeueInputBuffer(WAIT_US);
                    if (i >= 0) {
                        long pts = samplesQueued * 1_000_000L / pcmRate;
                        encoder.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        encoderInputEnded = true;
                    }
                }

                // Drain output every iteration to avoid codec buffer deadlock.
                while (true) {
                    int o = encoder.dequeueOutputBuffer(encoded, WAIT_US);
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (muxerStarted) throw new IOException("编码器输出格式重复改变");
                        muxerTrack = muxer.addTrack(encoder.getOutputFormat());
                        muxer.start();
                        muxerStarted = true;
                        lastForwardMs = SystemClock.elapsedRealtime();
                    } else if (o >= 0) {
                        ByteBuffer data = encoder.getOutputBuffer(o);
                        if (data != null && encoded.size > 0 &&
                                (encoded.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            if (!muxerStarted) throw new IOException("AAC 编码器没有输出格式");
                            data.position(encoded.offset);
                            data.limit(encoded.offset + encoded.size);
                            muxer.writeSampleData(muxerTrack, data, encoded);
                            lastForwardMs = SystemClock.elapsedRealtime();
                        }
                        encoderOutputEnded = (encoded.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                        encoder.releaseOutputBuffer(o, false);
                    } else {
                        break;
                    }
                    if (encoderOutputEnded) break;
                }
            }
            progress.update(96);
            if (!muxerStarted || target.length() == 0) {
                // Size is often buffered until muxer.stop(), so only verify muxer start here.
                if (!muxerStarted) throw new IOException("未生成 AAC 音频输出轨道");
            }
            muxer.stop();
            muxerStarted = false;
            if (target.length() < 128) throw new IOException("音频压缩结果为空");
            return target;
        } catch (Exception error) {
            if (target.exists()) target.delete();
            throw error;
        } finally {
            if (decoder != null) {
                try { decoder.stop(); } catch (Exception ignored) { }
                decoder.release();
            }
            if (encoder != null) {
                try { encoder.stop(); } catch (Exception ignored) { }
                encoder.release();
            }
            if (muxer != null) {
                if (muxerStarted) { try { muxer.stop(); } catch (Exception ignored) { } }
                muxer.release();
            }
            extractor.release();
        }
    }

    private static ByteBuffer downmixToMono(ByteBuffer samples, int channels) throws IOException {
        if (channels < 1 || channels > 8) throw new IOException("不支持的声道数：" + channels);
        final int frameBytes = channels * 2;
        final int frames = samples.remaining() / frameBytes;
        ByteBuffer mono = ByteBuffer.allocate(frames * 2);
        for (int i = 0; i < frames; i++) {
            int sum = 0;
            for (int ch = 0; ch < channels; ch++) {
                int lo = samples.get() & 255;
                int hi = samples.get();
                sum += (short) ((hi << 8) | lo);
            }
            short mixed = (short) (sum / channels);
            mono.put((byte) (mixed & 255));
            mono.put((byte) ((mixed >> 8) & 255));
        }
        mono.flip();
        return mono;
    }
}
