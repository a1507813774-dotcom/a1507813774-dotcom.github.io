package com.onec.audio;

import java.net.URI;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extract only a supported video URL, even from Chinese Bilibili sharing text. */
public final class LinkParser {
    private static final Pattern LINKS = Pattern.compile(
            "https?://[^\\s\\u200b\\u200c\\u200d\\u3000\\u3001\\u3002\\uff0c\\uff1b\\uff1a\\uff01\\uff1f\\u3010\\u3011\\u300a\\u300b\\u201c\\u201d\\u2018\\u2019<>]+",
            Pattern.CASE_INSENSITIVE);

    private LinkParser() { }

    public static String extract(String sharedText) {
        if (sharedText == null) return null;
        Matcher matcher = LINKS.matcher(sharedText);
        while (matcher.find()) {
            String candidate = stripTrailingPunctuation(matcher.group());
            try {
                URI uri = new URI(candidate);
                String scheme = uri.getScheme();
                String host = uri.getHost();
                if (scheme == null || host == null || !scheme.equalsIgnoreCase("https")
                        && !scheme.equalsIgnoreCase("http")) continue;
                host = host.toLowerCase(Locale.ROOT);
                if (isAllowedHost(host)) {
                    if (scheme.equalsIgnoreCase("http")) {
                        candidate = "https" + candidate.substring(candidate.indexOf(":"));
                    }
                    return candidate;
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static boolean isAllowedHost(String host) {
        return host.equals("youtu.be") || host.equals("youtube.com")
                || host.endsWith(".youtube.com") || host.equals("youtube-nocookie.com")
                || host.endsWith(".youtube-nocookie.com")
                || host.equals("bilibili.com") || host.endsWith(".bilibili.com")
                || host.equals("b23.tv") || host.endsWith(".b23.tv")
                || host.equals("bili2233.cn") || host.endsWith(".bili2233.cn");
    }

    private static String stripTrailingPunctuation(String url) {
        while (!url.isEmpty()) {
            char last = url.charAt(url.length() - 1);
            if (".,;:!?)]}\\\"'）］｝。！？，；：、".indexOf(last) < 0) break;
            url = url.substring(0, url.length() - 1);
        }
        return url;
    }
}
