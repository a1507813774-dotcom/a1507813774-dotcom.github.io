# 音频直取 v1.4 - 基于 v1.2 修复与增强

## 继承 v1.2 全部功能
- YouTube 与 Bilibili 分享链接识别，支持包含中文文案的分享信息。
- 音频下载到 `Download/音频直取/`，使用 MediaStore 持久 URI。
- 下载进度、取消、错误日志、打开文件、浏览目录、系统分享、记住上一次文件。
- 新增始终可见的「一键保存到 Google Drive」按钮，直接向已安装的 Google Drive 发起 Android 分享（Drive 可能要求用户确认上传位置）；不读取 Google 账号密码、不自动上传。

## 新增 32 kbps
- 在 Android 本地通过 MediaExtractor + MediaCodec + MediaMuxer 转为单声道 AAC-LC（32,000 bit/s）和 M4A 文件。
- 遇到手机无法压缩的音频格式时，保存原始音轨并提示，避免音频和分享入口一起消失。

## 兼容说明
- 保持旧包名 `com.onec.audiodirect`，versionCode 升为 5。**覆盖安装需要与当前设备旧版本使用相同 APK 签名证书。**
- 历史 v1.2/v1.3 使用临时 GitHub Actions 调试签名，原始私钥未存档，所以本次自动构建的调试 APK 不保证能覆盖安装旧版；遇到签名冲突需备份原数据后卸载旧版，再装新包。
- 后续建议提供稳定的签名密钥并妥善保管，才能保证跨版本覆盖更新。
