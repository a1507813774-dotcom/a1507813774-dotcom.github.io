package com.onec.audio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.content.SharedPreferences;
import android.util.Log;

import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import com.yausername.youtubedl_android.YoutubeDLResponse;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kotlin.Unit;
import kotlin.jvm.functions.Function3;

public class AudioService extends Service {
    public static final String ACTION_DOWNLOAD = "com.onec.audio.DOWNLOAD";
    public static final String ACTION_CANCEL = "com.onec.audio.CANCEL";
    public static final String ACTION_SKIP_COMPRESSION = "com.onec.audio.SKIP_COMPRESSION";
    public static final String KEY_COMPRESSING = "compressing";
    public static final String ACTION_STATUS = "com.onec.audio.STATUS";
    public static final String KEY_URL = "url";
    public static final String KEY_TEXT = "text";
    public static final String KEY_PROGRESS = "progress";
    public static final String KEY_BUSY = "busy";
    public static final String KEY_FILE_URI = "file_uri";
    public static final String KEY_LOG = "full_error_log";
    private static final String PREFS = "engine_settings";
    private static final long UPDATE_INTERVAL = 24L * 60L * 60L * 1000L;
    private static final String CHANNEL = "audio_downloads";
    private static final int NOTIFICATION_ID = 1099;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean busy = false;
    private volatile boolean cancelled = false;
    private volatile String processId = "";
    private volatile long lastUpdateMs = 0;
    private volatile int lastProgress = 0;
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(new NotificationChannel(CHANNEL,
                "音频下载进度", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_SKIP_COMPRESSION.equals(intent.getAction())) {
            // Legacy action is a no-op. v1.8 saves the original audio directly.
            return START_NOT_STICKY;
        }
        if (ACTION_CANCEL.equals(intent.getAction())) {
            if (busy) {
                cancelled = true;
                try { YoutubeDL.getInstance().destroyProcessById(processId); }
                catch (Exception ignored) { }
                status("正在取消…", lastProgress, true, null);
            }
            return START_NOT_STICKY;
        }
        if (!ACTION_DOWNLOAD.equals(intent.getAction())) return START_NOT_STICKY;
        if (busy) {
            status("已有下载任务，请等待完成", lastProgress, true, null);
            return START_NOT_STICKY;
        }
        final String url = intent.getStringExtra(KEY_URL);
        if (url == null || url.isEmpty()) return START_NOT_STICKY;
        busy = true;
        cancelled = false;
        lastProgress = 0;
        processId = "audio-" + SystemClock.elapsedRealtime();
        startForeground(NOTIFICATION_ID, notification("正在准备下载", 0, true));
        status("正在解析视频并下载原始音轨…", 0, true, null);
        worker.execute(() -> doDownload(url, startId));
        return START_NOT_STICKY;
    }

    private void doDownload(String url, int startId) {
        File taskDir = new File(getCacheDir(), "task_" + SystemClock.elapsedRealtime());
        taskDir.mkdirs();
        try {
            YoutubeDL.getInstance().init(getApplicationContext());
            if (cancelled) throw new InterruptedException("用户已取消");
            // v1.9: keep the verified bundled extractor on the download path.
            // Runtime updates can introduce untested behavior or delay downloads.
            if (cancelled) throw new InterruptedException("用户已取消");
            // YouTube now returns 403 for some direct M4A/DASH URLs even when
            // the same video offers a downloadable HLS (m3u8) audio track.
            // Pick formats deliberately and retry in fresh directories; yt-dlp's
            // own --retries cannot select a different extractor client/format.
            final boolean youtube = url.contains("youtube.com") || url.contains("youtu.be");
            final String[] selectors = youtube ? new String[]{
                    "ba[protocol!=m3u8][vcodec=none]/ba[protocol!=m3u8]", // direct first
                    "ba[protocol*=m3u8]/ba",       // HLS segments if direct fails
                    "ba[protocol*=m3u8]/ba"        // alternate YouTube clients
            } : new String[]{"ba"};
            File downloadDir = null;
            Exception lastDownloadError = null;
            StringBuilder attemptLog = new StringBuilder();
            for (int attempt = 0; attempt < selectors.length; attempt++) {
                if (cancelled) throw new InterruptedException("用户已取消");
                final int attemptIndex = attempt;
                File attemptDir = new File(taskDir, "attempt_" + (attemptIndex + 1));
                if (!attemptDir.mkdirs() && !attemptDir.isDirectory())
                    throw new IllegalStateException("无法创建下载临时文件夹");
                YoutubeDLRequest request = new YoutubeDLRequest(url);
                request.addOption("--no-playlist");
                request.addOption("--windows-filenames");
                request.addOption("--no-mtime");
                request.addOption("--no-continue");
                request.addOption("--remote-components", "ejs:github");
                request.addOption("--socket-timeout", "20");
                request.addOption("--retries", "1");
                request.addOption("--fragment-retries", "3");
                request.addOption("--concurrent-fragments", "6");
                request.addOption("--print", "after_move:AO_DURATION=%(duration)s");
                // The native library ships QuickJS, but yt-dlp requires its
                // executable path to be enabled explicitly on Android.
                File qjs = new File(getApplicationInfo().nativeLibraryDir, "libqjs.so");
                if (qjs.exists()) request.addOption("--js-runtimes", "quickjs:" + qjs.getAbsolutePath());
                if (youtube && attemptIndex == 2) {
                    request.addOption("--extractor-args", "youtube:player_client=default,mediaconnect,android");
                }
                request.addOption("-f", selectors[attemptIndex]);
                request.addOption("-o", new File(attemptDir, "%(title).110B [%(id)s].%(ext)s").getAbsolutePath());
                String mode = attemptIndex == 0 ? "直连音频流" :
                        (attemptIndex == 1 ? "并行下载分段音轨" : "切换 YouTube 播放器客户端");
                status("正在下载音频（方案 " + (attemptIndex + 1) + "/" + selectors.length + "：" + mode + "）…", 1, true, null);
                final Function3<Float, Long, String, Unit> cb = (percent, eta, line) -> {
                    if (cancelled) return Unit.INSTANCE;
                    int p = Math.max(1, Math.min(75, Math.round(percent * 0.75f)));
                    long now = SystemClock.elapsedRealtime();
                    if (p != lastProgress || now - lastUpdateMs > 1800) {
                        lastProgress = p;
                        lastUpdateMs = now;
                        status(String.format(Locale.CHINA, "下载音频（方案 %d/%d）：%d%%", attemptIndex + 1, selectors.length, p), p, true, null);
                    }
                    return Unit.INSTANCE;
                };
                try {
                    YoutubeDLResponse response = YoutubeDL.getInstance().execute(request, processId, cb);
                    if (cancelled) throw new InterruptedException("用户已取消");
                    File downloaded = findAudio(attemptDir);
                    if (downloaded == null || downloaded.length() < 1024) {
                        throw new IllegalStateException("下载结束但文件缺失或内容不足");
                    }
                    long declaredMs = expectedDurationMs(response.getOut());
                    long actualMs = AudioDuration.audioDurationMs(downloaded);
                    if (declaredMs >= 12000 && actualMs > 0
                            && actualMs + 2500 < declaredMs * 0.94) {
                        throw new IllegalStateException("音频不完整：原视频约 " +
                                (declaredMs / 1000) + " 秒，下载结果仅 " +
                                (actualMs / 1000) + " 秒");
                    }
                    downloadDir = attemptDir;
                    lastDownloadError = null;
                    break;
                } catch (Exception error) {
                    if (cancelled) throw new InterruptedException("用户已取消");
                    lastDownloadError = error;
                    String msg = error.getMessage() == null ? error.toString() : error.getMessage();
                    attemptLog.append("方案 ").append(attemptIndex + 1).append(" / ")
                            .append(mode).append(":\n").append(msg).append("\n\n");
                    if (attemptIndex + 1 < selectors.length) {
                        status("该音轨下载失败，正在切换其他格式…", 2, true, null);
                    }
                }
            }
            if (downloadDir == null) {
                String details = attemptLog.toString();
                throw new IllegalStateException("全部 " + selectors.length +
                        " 种下载方式失败：\n" + (details.isEmpty() ? "没有获取到可下载音轨" : details),
                        lastDownloadError);
            }
            if (cancelled) throw new InterruptedException("用户已取消");
            File file = findAudio(downloadDir);
            if (file == null) throw new IllegalStateException("未找到生成的音频文件");
            // v1.7: preserve original downloaded audio. No transcoding or codec thread.
            status("音频下载完成，正在保存原始音轨…", 93, true, null);
            Uri saved = saveToDownloads(file);
            getSharedPreferences("last_download", MODE_PRIVATE).edit()
                    .putString("uri", saved.toString())
                    .putString("name", file.getName()).apply();
            boolean automatic = getSharedPreferences("drive_upload", MODE_PRIVATE)
                    .getBoolean("enabled", false);
            if (automatic) {
                DriveUploadWorker.enqueue(this, saved);
                status("原始音频已保存 · 已加入 Google Drive 自动上传队列 · 下载/音频直取/" + file.getName(),
                        100, false, saved);
                notificationManager.notify(NOTIFICATION_ID, notification("原音频已保存，后台正在上传 Drive", 100, false));
            } else {
                status("原始音频已保存 · 尚未开启 Drive 自动上传 · 下载/音频直取/" + file.getName(),
                        100, false, saved);
                notificationManager.notify(NOTIFICATION_ID, notification("原始音轨已保存（自动上传未授权）", 100, false));
            }
        } catch (Exception e) {
            String raw = e.getMessage() == null ? e.toString() : e.getMessage();
            String detail = cancelled ? "下载已取消" : "下载失败：" + usefulMessage(raw);
            Log.e("AudioOneTap", "Download error", e);
            status(detail, 0, false, null, raw);
            notificationManager.notify(NOTIFICATION_ID, notification(detail, 0, false));
        } finally {
            // A non-interruptible vendor codec thread may still hold a temporary
            // output file. Preserve that directory until OS cache maintenance.
            clean(taskDir);
            busy = false;
            cancelled = false;
            stopForeground(STOP_FOREGROUND_DETACH);
            stopSelfResult(startId);
        }
    }

    private void tryUpdateEngine() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        long previous = prefs.getLong("last_check_time", 0L);
        long now = System.currentTimeMillis();
        // 每天最多检查一次 nightly，改善 YouTube 频繁变化的兼容性；失败时保留内置版本。
        if (previous > 0 && now - previous < UPDATE_INTERVAL) return;
        status("正在检查最新下载引擎（首次使用可能稍慢）…", 0, true, null);
        try {
            YoutubeDL.getInstance().updateYoutubeDL(getApplicationContext(), YoutubeDL.UpdateChannel.NIGHTLY.INSTANCE);
            prefs.edit().putLong("last_check_time", now).apply();
        } catch (Exception updateError) {
            // 更新失败不应阻止尝试本地已经打包的 yt-dlp。
            Log.w("AudioOneTap", "Engine update skipped; using bundled version", updateError);
            prefs.edit().putLong("last_check_time", now).apply();
        }
    }

    private String usefulMessage(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "下载引擎未返回具体原因";
        String[] lines = raw.replace('\r', '\n').split("\n");
        String best = "";
        String fallback = "";
        for (String line : lines) {
            String t = line.trim();
            if (t.isEmpty()) continue;
            if (t.contains("ERROR:") || t.contains("Traceback") || t.contains("HTTP Error") ||
                    t.contains("Sign in to confirm") || t.contains("Requested format is not available")) best = t;
            if (!t.toUpperCase(Locale.ROOT).startsWith("WARNING:") && !t.startsWith("[debug]")) fallback = t;
        }
        String message = best.isEmpty() ? fallback : best;
        if (message.isEmpty()) message = lines[lines.length-1].trim();
        if (message.contains("HTTP Error 403"))
            message += "（可能是音频格式或客户端验证限制，可复制日志）";
        return message.length() > 420 ? message.substring(0, 420) + "…" : message;
    }

    private static long expectedDurationMs(String output) {
        if (output == null || output.isEmpty()) return 0;
        Matcher match = Pattern.compile("AO_DURATION=([0-9]+(?:\\.[0-9]+)?)").matcher(output);
        if (!match.find()) return 0;
        try { return Math.round(Double.parseDouble(match.group(1)) * 1000.0); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private File findAudio(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        File largest = null;
        for (File f : files) {
            if (!f.isFile()) continue;
            String n = f.getName().toLowerCase(Locale.ROOT);
            if ((n.endsWith(".m4a") || n.endsWith(".webm") || n.endsWith(".opus")
                    || n.endsWith(".mp3") || n.endsWith(".mp4") || n.endsWith(".ogg"))
                    && f.length() > 1024 && (largest == null || f.length() > largest.length())) {
                largest = f;
            }
        }
        return largest;
    }

    private Uri saveToDownloads(File audio) throws Exception {
        final String name = audio.getName().length() > 185
                ? audio.getName().substring(0, 168) + audio.getName().substring(audio.getName().lastIndexOf('.'))
                : audio.getName();
        final String lower = name.toLowerCase(Locale.ROOT);
        final String mime = (lower.endsWith(".m4a") || lower.endsWith(".mp4")) ? "audio/mp4"
                : lower.endsWith(".mp3") ? "audio/mpeg"
                : lower.endsWith(".opus") ? "audio/ogg"
                : lower.endsWith(".ogg") ? "audio/ogg" : "audio/webm";
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/音频直取/");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("无法创建下载文件");
        try {
            try (FileInputStream input = new FileInputStream(audio);
                 OutputStream output = resolver.openOutputStream(uri)) {
                if (output == null) throw new IllegalStateException("无法写入下载文件");
                byte[] buffer = new byte[65536];
                int count;
                while ((count = input.read(buffer)) >= 0) {
                    if (cancelled) throw new InterruptedException("用户已取消");
                    output.write(buffer, 0, count);
                }
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            if (resolver.update(uri, done, null, null) <= 0)
                throw new IllegalStateException("文件保存后无法完成公开发布");
            // Check the published URI actually resolves to a nonempty file.
            try (android.os.ParcelFileDescriptor fd = resolver.openFileDescriptor(uri, "r")) {
                if (fd == null || fd.getStatSize() != audio.length())
                    throw new IllegalStateException("保存后的文件大小与源音频不一致");
            }
            return uri;
        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }
    }

    private Notification notification(String text, int progress, boolean ongoing) {
        Intent activity = new Intent(this, MainActivity.class);
        activity.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(this, 0, activity,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("音频直取")
                .setContentText(text)
                .setContentIntent(tap)
                .setOnlyAlertOnce(true)
                .setOngoing(ongoing);
        if (ongoing) n.setProgress(100, progress, progress == 0);
        else n.setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true);
        return n.build();
    }

    private void status(String text, int progress, boolean isBusy, Uri fileUri) {
        status(text, progress, isBusy, fileUri, null);
    }

    private void status(String text, int progress, boolean isBusy, Uri fileUri, String log) {
        Intent broadcast = new Intent(ACTION_STATUS).setPackage(getPackageName());
        if (log != null) broadcast.putExtra(KEY_LOG, log.length() > 12000 ? log.substring(log.length() - 12000) : log);
        broadcast.putExtra(KEY_TEXT, text);
        broadcast.putExtra(KEY_PROGRESS, progress);
        broadcast.putExtra(KEY_BUSY, isBusy);
        if (fileUri != null) broadcast.putExtra(KEY_FILE_URI, fileUri.toString());
        sendBroadcast(broadcast);
        if (isBusy) notificationManager.notify(NOTIFICATION_ID, notification(text, progress, true));
    }

    private void clean(File dir) {
        File[] children = dir.listFiles();
        if (children != null) for (File c : children) { if (c.isDirectory()) clean(c); else c.delete(); }
        dir.delete();
    }

    @Override public void onDestroy() { worker.shutdown(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
