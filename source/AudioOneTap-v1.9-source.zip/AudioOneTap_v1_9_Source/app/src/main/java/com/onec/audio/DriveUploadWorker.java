package com.onec.audio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.WorkManager;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.Tasks;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

/** Google Drive uploads run independently of the audio-download UI and survive process death. */
public class DriveUploadWorker extends Worker {
    public static final String KEY_STATUS = "drive_status";
    private static final String PREFS = "drive_upload";
    private static final String INPUT_URI = "audio_uri";
    private static final String CHANNEL = "drive_upload_results";

    public DriveUploadWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    public static AuthorizationRequest authorizationRequest() {
        return AuthorizationRequest.builder()
                .setRequestedScopes(Collections.singletonList(new Scope("https://www.googleapis.com/auth/drive.file")))
                .build();
    }

    public static void enqueue(Context context, Uri uri) {
        String input = uri.toString();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putString("pending_uri", input)
                .putString("status", "已排队；联网后自动上传至 Google Drive").apply();
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED).build();
        Data data = new Data.Builder().putString(INPUT_URI, input).build();
        OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(DriveUploadWorker.class)
                .setInputData(data).setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag("aot_drive_upload").build();
        // REPLACE supports explicit retry when prior WorkManager job failed or is stuck.
        WorkManager.getInstance(context).enqueueUniqueWork(
                "aot_drive_" + Integer.toHexString(input.hashCode()), ExistingWorkPolicy.REPLACE, work);
    }

    @NonNull @Override public Result doWork() {
        Context app = getApplicationContext();
        SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String source = getInputData().getString(INPUT_URI);
        if (source == null || source.isEmpty()) return Result.failure();
        if (!prefs.getBoolean("enabled", false)) {
            publish("Drive 自动上传尚未授权；本地音频保留", 0, false);
            return Result.failure();
        }
        Uri uri = Uri.parse(source);
        String recorded = prefs.getString("uploaded_" + source.hashCode(), "");
        if (!recorded.isEmpty()) {
            publish("该音频已上传 Google Drive", 100, false);
            return Result.success();
        }
        publish("正在连接 Google Drive，准备后台上传…", 2, false);
        try {
            AuthorizationResult auth = Tasks.await(
                    Identity.getAuthorizationClient(app).authorize(authorizationRequest()), 50, TimeUnit.SECONDS);
            if (auth.hasResolution() || auth.getAccessToken() == null || auth.getAccessToken().isEmpty()) {
                publish("Drive 授权过期：打开音频直取，点击重新授权后会继续上传", 0, true);
                return Result.failure();
            }
            String token = auth.getAccessToken();
            String id = DriveApiUploader.upload(app, uri, token,
                    progress -> publish("正在后台上传 Google Drive：" + progress + "%", progress, false));
            prefs.edit().putString("uploaded_" + source.hashCode(), id)
                    .putString("status", "上传成功：Google Drive / 音频直取").apply();
            publish("Google Drive 自动上传成功 · 原始音频仍保留在下载目录", 100, true);
            return Result.success();
        } catch (DriveApiUploader.AuthOrSetupException e) {
            Log.w("AudioOneTap", "Drive setup/permission failure", e);
            publish("Drive 授权或 API 配置异常：" + safe(e.getMessage()), 0, true);
            return Result.failure();
        } catch (Exception e) {
            Log.w("AudioOneTap", "Drive upload pending retry", e);
            if (getRunAttemptCount() >= 7) {
                publish("Drive 连续上传失败（原音频已保留）：" + safe(e.getMessage()), 0, true);
                return Result.failure();
            }
            publish("Drive 上传暂未完成，将自动重试（第 " + (getRunAttemptCount() + 1) + " 次）："
                    + safe(e.getMessage()), 0, false);
            return Result.retry();
        }
    }

    private String safe(String s) {
        if (s == null || s.trim().isEmpty()) return "未知连接问题";
        return s.length() <= 145 ? s : s.substring(0, 145) + "…";
    }

    private void publish(String message, int progress, boolean notify) {
        Context app = getApplicationContext();
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("status", message).apply();
        Intent i = new Intent(AudioService.ACTION_STATUS).setPackage(app.getPackageName());
        i.putExtra(AudioService.KEY_TEXT, message);
        i.putExtra(AudioService.KEY_PROGRESS, Math.max(0, Math.min(100, progress)));
        i.putExtra(KEY_STATUS, message);
        app.sendBroadcast(i);
        if (!notify) return;
        NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,
                "Google Drive 自动上传结果", NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent tap = PendingIntent.getActivity(app, 88,
                new Intent(app, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(app, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                .setContentTitle("音频直取 · Drive 自动上传")
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true).setContentIntent(tap).build();
        nm.notify(1118, n);
    }
}
