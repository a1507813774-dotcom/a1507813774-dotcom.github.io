package com.onec.audio;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.content.ContentResolver;
import android.provider.DocumentsContract;
import android.os.ParcelFileDescriptor;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.content.IntentSender;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.common.api.Scope;
import java.util.Collections;
import android.app.AlertDialog;
import java.security.MessageDigest;
import android.content.pm.Signature;
import java.util.Locale;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity {
    private static final int BG = Color.rgb(11, 17, 34);
    private static final int CARD = Color.rgb(23, 34, 55);
    private static final int TEXT = Color.rgb(240, 247, 253);
    private static final int MUTED = Color.rgb(155, 172, 192);
    private static final int MINT = Color.rgb(66, 231, 183);
    private EditText input;
    private TextView status;
    private ProgressBar bar;
    private Button download;
    private Button cancel;
    private Button skipCompression; // no longer displayed
    private Button openFile;
    private Button shareFile;
    private Button saveDrive;
    private Button connectDrive;
    private Button retryDrive;
    private TextView driveStatus;
    private static final int DRIVE_AUTH_RESULT = 602;
    private Button browseFiles;
    private Button copyError;
    private String lastErrorLog = "";
    private String latestUri;
    private boolean busy = false;
    private final BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            status.setText(intent.getStringExtra(AudioService.KEY_TEXT));
            bar.setProgress(intent.getIntExtra(AudioService.KEY_PROGRESS, 0));
            setBusy(intent.getBooleanExtra(AudioService.KEY_BUSY, false));

            String uri = intent.getStringExtra(AudioService.KEY_FILE_URI);
            if (uri != null) {
                latestUri = uri;
                openFile.setVisibility(View.VISIBLE);
                shareFile.setVisibility(View.VISIBLE);
                saveDrive.setText("备用：手动保存到 Drive");
            }
            String driveMsg = intent.getStringExtra(DriveUploadWorker.KEY_STATUS);
            if (driveMsg != null) refreshDriveStatus();
            String errorLog = intent.getStringExtra(AudioService.KEY_LOG);
            if (errorLog != null) {
                lastErrorLog = errorLog;
                copyError.setVisibility(View.VISIBLE);
            }
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
        restoreLastFile();
        refreshDriveStatus();
        handleIncoming(getIntent());
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    @Override protected void onStart() {
        super.onStart();
        registerReceiver(updateReceiver, new IntentFilter(AudioService.ACTION_STATUS), Context.RECEIVER_NOT_EXPORTED);
        restoreLastFile();
        refreshDriveStatus();
    }
    @Override protected void onStop() { unregisterReceiver(updateReceiver); super.onStop(); }

    private void handleIncoming(Intent intent) {
        if (intent == null) return;
        String link = null;
        if (Intent.ACTION_SEND.equals(intent.getAction())) link = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null)
            link = intent.getData().toString();
        if (link != null) {
            String url = LinkParser.extract(link);
            input.setText(url == null ? link : url);
            // 从分享菜单打开时，只有可信来源链接才自动开始下载。
            if (url != null) input.post(() -> startDownload(url));
        }
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(24), dp(54), dp(24), dp(30));
        scroll.addView(outer);

        TextView insignia = label("♫  ↓", 39, MINT, Typeface.BOLD);
        insignia.setGravity(Gravity.CENTER);
        insignia.setBackground(gradient(Color.rgb(30, 89, 100), Color.rgb(15, 50, 79), 26));
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(88), dp(88));
        logoParams.bottomMargin = dp(24);
        outer.addView(insignia, logoParams);
        outer.addView(label("音频直取 · 1.9", 30, TEXT, Typeface.BOLD));
        TextView subheading = label("原始音轨 · 下载后自动上传 Drive", 15, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(10);
        outer.addView(subheading, subParams);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(22), dp(18), dp(22));
        panel.setBackground(shape(CARD, 25));
        LinearLayout.LayoutParams panelParams = new LinearLayout.LayoutParams(-1, -2);
        panelParams.topMargin = dp(36);
        outer.addView(panel, panelParams);
        panel.addView(label("YouTube / Bilibili 分享链接", 15, TEXT, Typeface.BOLD));
        input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(2);
        input.setMaxLines(4);
        input.setTextSize(15);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("直接粘贴完整分享文案（包含中文介绍也可以）…");
        input.setBackground(shape(Color.rgb(13, 23, 42), 15));
        input.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, -2);
        inputParams.topMargin = dp(16);
        panel.addView(input, inputParams);

        Button paste = button("粘贴剪贴板", Color.rgb(44, 63, 83), TEXT);
        LinearLayout.LayoutParams pasteParams = new LinearLayout.LayoutParams(-1, dp(46));
        pasteParams.topMargin = dp(12);
        panel.addView(paste, pasteParams);
        paste.setOnClickListener(v -> pasteClipboard());

        download = button("↓   一键下载纯音频", MINT, Color.rgb(9, 30, 37));
        LinearLayout.LayoutParams downloadParams = new LinearLayout.LayoutParams(-1, dp(58));
        downloadParams.topMargin = dp(21);
        panel.addView(download, downloadParams);
        download.setOnClickListener(v -> startDownload(input.getText().toString().trim()));

        cancel = button("取消下载", Color.rgb(83, 45, 56), TEXT);
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-1, dp(46));
        cancelParams.topMargin = dp(10);
        panel.addView(cancel, cancelParams);
        cancel.setVisibility(View.GONE);
        cancel.setOnClickListener(v -> startService(new Intent(this, AudioService.class).setAction(AudioService.ACTION_CANCEL)));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT));
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, dp(6));
        barParams.topMargin = dp(25);
        panel.addView(bar, barParams);
        status = label("准备就绪 · 原始音轨不压缩", 13, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(15);
        panel.addView(status, statusParams);
        openFile = button("打开已下载文件", Color.rgb(38, 74, 68), TEXT);
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(-1, dp(48));
        openParams.topMargin = dp(14);
        panel.addView(openFile, openParams);
        openFile.setVisibility(View.GONE);
        openFile.setOnClickListener(v -> openDownloaded());
        connectDrive = button("☁ 连接 Google Drive · 开启自动上传", Color.rgb(41, 102, 142), TEXT);
        LinearLayout.LayoutParams connectParams = new LinearLayout.LayoutParams(-1, dp(55));
        connectParams.topMargin = dp(14);
        panel.addView(connectDrive, connectParams);
        connectDrive.setOnClickListener(v -> requestDriveAuthorization());
        driveStatus = label("自动上传状态：未授权", 13, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams driveStatusParams = new LinearLayout.LayoutParams(-1, -2);
        driveStatusParams.topMargin = dp(8);
        panel.addView(driveStatus, driveStatusParams);
        retryDrive = button("重新尝试上传上个音频", Color.rgb(43, 76, 91), TEXT);
        LinearLayout.LayoutParams retryParams = new LinearLayout.LayoutParams(-1, dp(46));
        retryParams.topMargin = dp(9);
        panel.addView(retryDrive, retryParams);
        retryDrive.setOnClickListener(v -> retryLastUpload());
        Button cloudGuide = button("Drive 授权失败？查看首次设置说明", Color.rgb(46, 60, 77), TEXT);
        LinearLayout.LayoutParams guideParams = new LinearLayout.LayoutParams(-1, dp(43));
        guideParams.topMargin = dp(8);
        panel.addView(cloudGuide, guideParams);
        cloudGuide.setOnClickListener(v -> showDriveSetupGuide());

        saveDrive = button("备用：手动保存到 Drive", Color.rgb(42, 83, 153), TEXT);
        LinearLayout.LayoutParams driveParams = new LinearLayout.LayoutParams(-1, dp(54));
        driveParams.topMargin = dp(12);
        panel.addView(saveDrive, driveParams);
        saveDrive.setOnClickListener(v -> saveDownloadedToDrive());
        TextView driveHint = label("自动上传需要先授权一次；上述按钮仅用于未能自动上传时的手动备份。", 12, MUTED, Typeface.NORMAL);
        LinearLayout.LayoutParams driveHintParams = new LinearLayout.LayoutParams(-1, -2);
        driveHintParams.topMargin = dp(6);
        panel.addView(driveHint, driveHintParams);

        shareFile = button("分享音频到 Drive / 其他应用", Color.rgb(38, 74, 68), TEXT);
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(-1, dp(48));
        shareParams.topMargin = dp(10);
        panel.addView(shareFile, shareParams);
        shareFile.setVisibility(View.GONE);
        shareFile.setOnClickListener(v -> shareDownloaded());
        browseFiles = button("浏览下载目录", Color.rgb(44, 63, 83), TEXT);
        LinearLayout.LayoutParams browseParams = new LinearLayout.LayoutParams(-1, dp(46));
        browseParams.topMargin = dp(10);
        panel.addView(browseFiles, browseParams);
        browseFiles.setOnClickListener(v -> browseDownloadFolder());
        copyError = button("复制详细错误日志", Color.rgb(63, 69, 89), TEXT);
        LinearLayout.LayoutParams errorParams = new LinearLayout.LayoutParams(-1, dp(46));
        errorParams.topMargin = dp(10);
        panel.addView(copyError, errorParams);
        copyError.setVisibility(View.GONE);
        copyError.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("音频直取错误日志", lastErrorLog));
            Toast.makeText(this, "已复制完整错误日志", Toast.LENGTH_SHORT).show();
        });

        TextView hint = label("📂 本地位置：下载 / 音频直取\n\n• 不再压缩，直接保存网站提供的原始音轨\n• Drive 授权成功后：自动后台上传到云端的「音频直取」文件夹\n• 断网时排队重试，不删除本地文件\n• 支持 YouTube 和 Bilibili 分享链接\n• 不收集 Google 密码；仅申请本应用创建文件所需的 Drive 权限", 13, MUTED, Typeface.NORMAL);
        hint.setLineSpacing(dp(3), 1.2f);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(30);
        outer.addView(hint, hintParams);
        setContentView(scroll);
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip().getItemCount() == 0) {
            Toast.makeText(this, "剪贴板没有内容", Toast.LENGTH_SHORT).show();
            return;
        }
        CharSequence item = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
        String raw = item == null ? "" : item.toString();
        String url = LinkParser.extract(raw);
        input.setText(url == null ? raw : url);
        if (url != null && !raw.trim().equals(url))
            Toast.makeText(this, "已从分享文案提取视频链接", Toast.LENGTH_SHORT).show();
    }

    private void startDownload(String text) {
        if (busy) return;
        String url = LinkParser.extract(text);
        if (url == null) {
            input.setError("请粘贴 YouTube 或 Bilibili 视频分享链接");
            return;
        }
        input.setText(url);
        setBusy(true);
        latestUri = null;
        lastErrorLog = "";
        openFile.setVisibility(View.GONE);
        shareFile.setVisibility(View.GONE);
        saveDrive.setText("备用：手动保存到 Drive（下载后可用）");
        copyError.setVisibility(View.GONE);
        status.setText("正在启动下载…");
        bar.setProgress(0);
        try {
            Intent service = new Intent(this, AudioService.class).setAction(AudioService.ACTION_DOWNLOAD);
            service.putExtra(AudioService.KEY_URL, url);
            startForegroundService(service);
        } catch (Exception e) {
            setBusy(false);
            status.setText("启动失败：" + e.getMessage());
        }
    }

    /** Retain the MediaStore URI, so reopening the app still exposes the audio file. */
    private void restoreLastFile() {
        if (busy) return;
        SharedPreferences prefs = getSharedPreferences("last_download", MODE_PRIVATE);
        String saved = prefs.getString("uri", null);
        if (saved == null || saved.isEmpty()) return;
        try (ParcelFileDescriptor descriptor = getContentResolver()
                .openFileDescriptor(Uri.parse(saved), "r")) {
            if (descriptor == null) return;
            latestUri = saved;
            openFile.setVisibility(View.VISIBLE);
            shareFile.setVisibility(View.VISIBLE);
            saveDrive.setText("备用：手动保存到 Drive");
        } catch (Exception e) {
            prefs.edit().remove("uri").apply();
        }
    }

    /** Open Google Drive's Android share target with the actual saved MediaStore URI.
     * This is a single in-app tap; Drive may still ask user for folder/upload confirmation.
     * Google account credentials are never collected by this application.
     */
    private void saveDownloadedToDrive() {
        if (TextUtils.isEmpty(latestUri)) {
            restoreLastFile();
        }
        if (TextUtils.isEmpty(latestUri)) {
            Toast.makeText(this, "请先下载音频；完成后点这里保存到 Drive", Toast.LENGTH_LONG).show();
            return;
        }
        Uri uri = Uri.parse(latestUri);
        try (ParcelFileDescriptor fd = getContentResolver().openFileDescriptor(uri, "r")) {
            if (fd == null || fd.getStatSize() == 0) {
                Toast.makeText(this, "下载文件无法读取，请重新下载", Toast.LENGTH_LONG).show();
                return;
            }
        } catch (Exception e) {
            Toast.makeText(this, "下载文件已被移动或删除，请重新下载", Toast.LENGTH_LONG).show();
            return;
        }
        Intent drive = new Intent(Intent.ACTION_SEND);
        String mime = getContentResolver().getType(uri);
        drive.setType((mime != null && mime.startsWith("audio/")) ? mime : "audio/*");
        drive.putExtra(Intent.EXTRA_STREAM, uri);
        drive.setClipData(ClipData.newUri(getContentResolver(), "音频直取", uri));
        drive.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        drive.setPackage("com.google.android.apps.docs");
        try {
            startActivity(drive);
        } catch (android.content.ActivityNotFoundException e) {
            // If Drive is missing or has no matching share activity, let user pick a target.
            shareDownloaded();
            Toast.makeText(this, "未找到 Drive 保存入口，请在分享菜单选择 Drive", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "无法打开 Drive：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void requestDriveAuthorization() {
        connectDrive.setEnabled(false);
        connectDrive.setText("正在连接 Google 账户…");
        Identity.getAuthorizationClient(this).authorize(DriveUploadWorker.authorizationRequest())
            .addOnSuccessListener(result -> {
                connectDrive.setEnabled(true);
                connectDrive.setText("☁ 重新授权 / 检查 Drive 连接");
                if (result.hasResolution()) {
                    try {
                        startIntentSenderForResult(result.getPendingIntent().getIntentSender(),
                            DRIVE_AUTH_RESULT, null, 0, 0, 0);
                    } catch (IntentSender.SendIntentException e) {
                        showDriveAuthFailure(e);
                    }
                } else {
                    onDriveAuthorized(result);
                }
            })
            .addOnFailureListener(e -> {
                connectDrive.setEnabled(true);
                connectDrive.setText("☁ 连接 Google Drive · 开启自动上传");
                showDriveAuthFailure(e);
            });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != DRIVE_AUTH_RESULT) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Google Drive 授权未完成", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            AuthorizationResult auth = Identity.getAuthorizationClient(this)
                .getAuthorizationResultFromIntent(data);
            onDriveAuthorized(auth);
        } catch (Exception e) { showDriveAuthFailure(e); }
    }

    private void onDriveAuthorized(AuthorizationResult result) {
        if (result.getAccessToken() == null || result.getAccessToken().isEmpty()) {
            Toast.makeText(this, "尚未获取 Google Drive 授权", Toast.LENGTH_LONG).show();
            return;
        }
        getSharedPreferences("drive_upload", MODE_PRIVATE).edit()
            .putBoolean("enabled", true)
            .putString("status", "授权完成；后续下载会自动上传到 Drive").apply();
        refreshDriveStatus();
        retryLastUpload();
        Toast.makeText(this, "Drive 已授权。后续音频下载完成将自动上传", Toast.LENGTH_LONG).show();
    }

    private void showDriveAuthFailure(Exception error) {
        String text = String.valueOf(error.getMessage());
        Toast.makeText(this, "授权失败：" + text, Toast.LENGTH_LONG).show();
        getSharedPreferences("drive_upload", MODE_PRIVATE).edit()
            .putString("status", "授权失败：" + text).apply();
        refreshDriveStatus();
        if (text.contains("DEVELOPER_ERROR") || text.contains("10:")) showDriveSetupGuide();
    }

    private void retryLastUpload() {
        String saved = getSharedPreferences("last_download", MODE_PRIVATE).getString("uri", "");
        if (saved.isEmpty()) {
            Toast.makeText(this, "没有待上传音频", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!getSharedPreferences("drive_upload", MODE_PRIVATE).getBoolean("enabled", false)) {
            Toast.makeText(this, "请先连接并授权 Google Drive", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            DriveUploadWorker.enqueue(this, Uri.parse(saved));
            refreshDriveStatus();
        } catch (Exception e) {
            Toast.makeText(this, "无法加入上传队列：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void refreshDriveStatus() {
        if (driveStatus == null || connectDrive == null || retryDrive == null) return;
        SharedPreferences pref = getSharedPreferences("drive_upload", MODE_PRIVATE);
        boolean enabled = pref.getBoolean("enabled", false);
        driveStatus.setText((enabled ? "Drive 自动上传：已开启。" : "Drive 自动上传：未授权。") +
                "\n" + pref.getString("status", enabled ? "等待音频下载" : "首次需要连接 Google 账户"));
        connectDrive.setText(enabled ? "☁ 重新授权 / 检查 Drive 连接" : "☁ 连接 Google Drive · 开启自动上传");
        retryDrive.setEnabled(enabled);
        retryDrive.setAlpha(enabled ? 1.0f : 0.5f);
    }

    private String signingFingerprint() {
        try {
            Signature[] signatures = getPackageManager().getPackageInfo(getPackageName(),
                    PackageManager.GET_SIGNING_CERTIFICATES).signingInfo.getApkContentsSigners();
            byte[] digest = MessageDigest.getInstance("SHA-1").digest(signatures[0].toByteArray());
            StringBuilder out = new StringBuilder();
            for (byte b : digest) {
                if (out.length() > 0) out.append(':');
                out.append(String.format(Locale.ROOT, "%02X", b & 255));
            }
            return out.toString();
        } catch (Exception e) { return "请通过 keytool 查看 APK 证书"; }
    }

    private void showDriveSetupGuide() {
        final String packageName = getPackageName();
        final String sha1 = signingFingerprint();
        final String info = "真正的自动上传使用 Google Drive API。首次必须在 Google Cloud 创建项目、启用 Drive API、配置 OAuth 同意界面和 Android OAuth 客户端。\n\n" +
              "应用包名：" + packageName + "\n\n签名 SHA-1：\n" + sha1 +
              "\n\n把包名和 SHA-1 填入 Google Cloud → Google Auth Platform → 客户端 → Android，然后把自己的 Google 账号加入测试用户。\n\n" +
              "创建后回到这里点『连接 Google Drive』。未完成注册时，本应用仍然可以下载原始音频并手动分享到 Drive，但无法自动上传。";
        new AlertDialog.Builder(this).setTitle("Google Drive 自动上传的首次配置")
                .setMessage(info)
                .setPositiveButton("复制包名与 SHA-1", (d, which) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Drive OAuth 应用资料", "包名：" + packageName + "\nSHA-1：" + sha1));
                })
                .setNegativeButton("关闭", null).show();
    }

    private void shareDownloaded() {
        if (TextUtils.isEmpty(latestUri)) return;
        Uri uri = Uri.parse(latestUri);
        try {
            String type = getContentResolver().getType(uri);
            if (type == null || !type.startsWith("audio/")) type = "audio/*";
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(type);
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.setClipData(ClipData.newUri(getContentResolver(), "已下载音频", uri));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "分享音频文件"));
        } catch (Exception e) {
            Toast.makeText(this, "分享失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Launch the system's file picker with a hint for our actual Downloads directory. */
    private void browseDownloadFolder() {
        try {
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("audio/*");
            Uri folder = DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", "primary:Download/音频直取");
            picker.putExtra(DocumentsContract.EXTRA_INITIAL_URI, folder);
            startActivity(picker);
        } catch (Exception e) {
            Toast.makeText(this, "请在文件管理器中进入 下载/音频直取", Toast.LENGTH_LONG).show();
        }
    }

    private void setBusy(boolean value) {
        busy = value;
        download.setEnabled(!value);
        download.setAlpha(value ? 0.5f : 1f);
        cancel.setVisibility(value ? View.VISIBLE : View.GONE);

    }

    private void openDownloaded() {
        if (TextUtils.isEmpty(latestUri)) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(latestUri));
            i.setDataAndType(Uri.parse(latestUri), "audio/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "打开音频"));
        } catch (Exception e) { Toast.makeText(this, "请打开系统下载文件夹查看", Toast.LENGTH_LONG).show(); }
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String s, int size, int color, int style) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", style));
        return t;
    }
    private Button button(String s, int background, int foreground) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(14); b.setAllCaps(false); b.setTextColor(foreground);
        b.setSingleLine(true); b.setEllipsize(TextUtils.TruncateAt.END);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(shape(background, 15));
        return b;
    }
    private GradientDrawable shape(int color, int corner) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color); drawable.setCornerRadius(dp(corner));
        return drawable;
    }
    private GradientDrawable gradient(int c1, int c2, int corner) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(corner)); return g;
    }
}
