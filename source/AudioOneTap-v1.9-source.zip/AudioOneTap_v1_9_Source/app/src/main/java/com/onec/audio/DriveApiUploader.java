package com.onec.audio;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Restricted drive.file OAuth scope, directly uploads to an app-created Drive folder. */
public class DriveApiUploader {
    public interface Progress { void update(int progress); }
    public static class AuthOrSetupException extends IOException {
        public AuthOrSetupException(String message) { super(message); }
    }

    private static HttpURLConnection connection(String url, String method, String token) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(false);
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("Accept", "application/json");
        return c;
    }

    private static JSONObject json(HttpURLConnection conn) throws IOException {
        int code = conn.getResponseCode();
        InputStream input = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        String data = "";
        if (input != null) try (InputStream in = input; ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] tmp = new byte[8192]; int n;
            while ((n = in.read(tmp)) != -1 && b.size() < 128000) b.write(tmp, 0, n);
            data = b.toString("UTF-8");
        }
        if (code == 401 || code == 403) {
            String msg = data.contains("accessNotConfigured") || data.contains("SERVICE_DISABLED")
                    ? "Google Cloud 尚未启用 Drive API"
                    : "Google Drive 拒绝访问（HTTP " + code + "）；请检查 OAuth 签名和 Drive API";
            throw new AuthOrSetupException(msg);
        }
        if (code < 200 || code >= 300) throw new IOException("Drive API HTTP " + code + "：" + trim(data));
        try { return data.isEmpty() ? new JSONObject() : new JSONObject(data); }
        catch (Exception e) { throw new IOException("Drive 返回无效 JSON", e); }
    }

    private static String trim(String data) {
        return data.length() > 260 ? data.substring(0,260) : data;
    }

    private static JSONObject get(String url, String token) throws IOException {
        HttpURLConnection c = connection(url, "GET", token);
        try { return json(c); } finally { c.disconnect(); }
    }

    private static JSONObject post(String url, String token, JSONObject obj) throws IOException {
        HttpURLConnection c = connection(url, "POST", token);
        c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        byte[] data = obj.toString().getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(data.length);
        try { try (OutputStream out=c.getOutputStream()) {out.write(data);} return json(c); }
        finally {c.disconnect();}
    }

    private static String ensureFolder(String token) throws Exception {
        // drive.file can see this application's own files/folders; it cannot browse all files.
        String q = "name = '音频直取' and mimeType = 'application/vnd.google-apps.folder' and 'root' in parents and trashed = false";
        String url = "https://www.googleapis.com/drive/v3/files?fields=files(id,name),nextPageToken&pageSize=25&q="
                + URLEncoder.encode(q, "UTF-8");
        JSONArray files = get(url, token).optJSONArray("files");
        if (files != null && files.length() > 0) {
            String folder = files.optJSONObject(0).optString("id", "");
            if (!folder.isEmpty()) return folder;
        }
        JSONObject created = post("https://www.googleapis.com/drive/v3/files?fields=id", token,
                new JSONObject().put("name", "音频直取")
                        .put("mimeType", "application/vnd.google-apps.folder"));
        String id = created.optString("id", "");
        if (id.isEmpty()) throw new IOException("Drive 文件夹创建后未返回 ID");
        return id;
    }

    public static String upload(Context context, Uri file, String token, Progress progress) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        String name = null; long length = -1;
        try (Cursor c = resolver.query(file, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int a=c.getColumnIndex(OpenableColumns.DISPLAY_NAME), b=c.getColumnIndex(OpenableColumns.SIZE);
                if (a>=0) name=c.getString(a);
                if (b>=0 && !c.isNull(b)) length=c.getLong(b);
            }
        }
        if (name == null || name.trim().isEmpty()) name = "音频直取_" + System.currentTimeMillis() + ".m4a";
        if (length <= 0) throw new IOException("下载目录中找不到完整音频文件大小，无法上传");
        String mime = resolver.getType(file);
        if (mime == null || !mime.startsWith("audio/")) mime="application/octet-stream";
        String folderId = ensureFolder(token);
        JSONObject metadata = new JSONObject().put("name", name).put("parents", new JSONArray().put(folderId))
                .put("mimeType", mime);
        String endpoint = "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,webViewLink";
        HttpURLConnection c = connection(endpoint, "POST", token);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        c.setRequestProperty("X-Upload-Content-Type", mime);
        c.setRequestProperty("X-Upload-Content-Length", Long.toString(length));
        byte[] meta = metadata.toString().getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(meta.length);
        String session;
        try {
            try (OutputStream out=c.getOutputStream()) {out.write(meta);}
            int code=c.getResponseCode();
            if (code==401 || code==403) json(c); // throws explanatory auth error
            if (code<200 || code>=300) throw new IOException("Drive 创建上传任务失败 HTTP " + code);
            session=c.getHeaderField("Location");
        } finally {c.disconnect();}
        if (session==null || session.isEmpty()) throw new IOException("Drive 未返回断点续传地址");
        Uri sessionUri = Uri.parse(session);
        if (!"https".equalsIgnoreCase(sessionUri.getScheme()) || sessionUri.getHost()==null ||
                !(sessionUri.getHost().equals("googleapis.com") || sessionUri.getHost().endsWith(".googleapis.com"))) {
            throw new IOException("拒绝不可信的 Drive 上传地址");
        }
        final int CHUNK = 1024*1024; // 1 MiB is a multiple of Drive's 256 KiB chunk alignment
        byte[] buf=new byte[CHUNK]; long position=0;
        try (InputStream in = new BufferedInputStream(resolver.openInputStream(file), CHUNK)) {
            if (in==null) throw new IOException("本地音频已被移动或删除");
            while (position<length) {
                if (Thread.currentThread().isInterrupted()) throw new IOException("上传已被系统停止，将重试");
                int desired=(int)Math.min(CHUNK,length-position), read=0;
                while (read<desired) {
                    int n=in.read(buf,read,desired-read);
                    if (n<0) throw new IOException("原音频意外提前结束，上传已中止");
                    read+=n;
                }
                HttpURLConnection part=connection(session,"PUT",token);
                part.setDoOutput(true);
                part.setRequestProperty("Content-Type",mime);
                part.setRequestProperty("Content-Range", "bytes "+position+"-"+(position+read-1)+"/"+length);
                part.setFixedLengthStreamingMode(read);
                try {
                    try (OutputStream out=part.getOutputStream()) {out.write(buf,0,read);}
                    int code=part.getResponseCode();
                    if(code==308){
                        String range=part.getHeaderField("Range");
                        long accepted=(range!=null && range.contains("-")) ?
                                Long.parseLong(range.substring(range.lastIndexOf('-')+1))+1 : 0;
                        if(accepted!=position+read) throw new IOException("Drive 分片确认不完整，将重试上传");
                        position=accepted;
                    } else if(code>=200 && code<300) {
                        JSONObject response=json(part);
                        String id=response.optString("id","");
                        if(id.isEmpty()) throw new IOException("Drive 上传后未返回文件 ID");
                        progress.update(100);
                        return id;
                    } else if(code==401 || code==403){
                        json(part); // throws
                    } else throw new IOException("Drive 上传分片失败 HTTP " + code);
                } finally {part.disconnect();}
                progress.update((int)Math.max(1,Math.min(99,position*100/length)));
            }
        }
        throw new IOException("Drive 上传完成但未返回成功确认");
    }
}
