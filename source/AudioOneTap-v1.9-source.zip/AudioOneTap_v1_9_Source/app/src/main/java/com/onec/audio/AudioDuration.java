package com.onec.audio;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;

/** Read existing audio duration for completeness checks; never decodes or transcodes audio. */
final class AudioDuration {
    static long audioDurationMs(File input) {
        MediaExtractor scan = new MediaExtractor();
        try {
            scan.setDataSource(input.getAbsolutePath());
            for (int i=0; i<scan.getTrackCount(); i++) {
                MediaFormat fmt=scan.getTrackFormat(i);
                String mime=fmt.getString(MediaFormat.KEY_MIME);
                if (mime==null || !mime.startsWith("audio/")) continue;
                if (fmt.containsKey(MediaFormat.KEY_DURATION)) {
                    long d=fmt.getLong(MediaFormat.KEY_DURATION);
                    if (d>0) return d/1000L;
                }
                scan.selectTrack(i);
                long last=0;
                for(int n=0;n<1000000;n++) {
                    long pts=scan.getSampleTime();
                    if(pts<0) break;
                    last=pts;
                    if(!scan.advance()) break;
                }
                return last>0 ? last/1000L : 0;
            }
        } catch(Exception ignored){return 0;}
        finally {scan.release();}
        return 0;
    }
    private AudioDuration(){}
}
