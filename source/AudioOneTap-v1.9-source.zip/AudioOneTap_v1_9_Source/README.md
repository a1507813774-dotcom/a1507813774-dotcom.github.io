# 音频直取 v1.9 — 原始音轨 + Google Drive 自动上传

## v1.9 变更

- 默认只下载原始音轨，不做 AAC/32 kbps 转码，也不调用 Android `MediaCodec`。
- 在 v1.7 下载质量校验的基础上保留 YouTube/Bilibili 分享链接提取、YouTube HLS 音轨优先和失败自动换格式尝试。
- 音频先保存到手机 `下载/音频直取/`，成功之后加入 WorkManager 后台自动上传队列；离开应用后也可以上传。
- 使用 Google Play services AuthorizationClient 获取 `drive.file` 范围的 OAuth 访问令牌。首次用户授权一次；之后定期通过官方接口静默获取短期令牌。
- 自动在用户的 Google Drive 根目录中建立本应用的 `音频直取` 文件夹，然后上传音频（使用 Google Drive API v3 resumable uploads）。
- 断网等待并重试；上传失败保留本地原件，不会误显示「已上传」。保留手动分享到 Google Drive 功能。
- 使用与 v1.5 / v1.6 相同的包名 `com.onec.audiodirect` 和签名密钥；`versionCode=10`。

## 首次 Google Cloud 配置（必须完成，不能绕过）

Google Drive 不允许任意第三方 APK 在未获得 OAuth 应用身份的情况下，直接调用自动上传 API。用户需要：

1. 在 Google Cloud Console 创建（或选择）项目，启用 **Google Drive API**。
2. 在 Google Auth Platform 创建 OAuth 同意界面；测试状态时，把要登录的 Google 账号加入测试用户。
3. 创建 **Android OAuth 客户端**，填写包名 `com.onec.audiodirect` 与最终签名 APK 的 SHA-1 证书指纹。
4. 手机安装 APK，打开「连接 Google Drive · 开启自动上传」，选择账号并授权访问应用创建/使用的文件。
5. 授权成功后，每次下载完成自动后台上传，手机无需保持在本应用窗口。

未完成 OAuth 配置时，仍可正常下载原始音轨并用备用的手动分享按钮保存到 Drive；APP 不会假装自动上传已经启动。不能将 ChatGPT 的 Drive 连接或 Drive 应用登录状态当作该 APK 的 OAuth 授权。

如果使用不同的 APK 签名证书，必须同步更新 Google Cloud OAuth 的 SHA-1 客户端注册；否则 Drive 授权可能返回 `DEVELOPER_ERROR`。

## 隐私和安全

- 不在应用中索取 Google 密码，不把 OAuth access token 写入日志或偏好设置；短期令牌由 Google Play services 管理。
- 使用 `drive.file` 最小必要授权范围，仅创建或操作本应用产生的文件，不读取整个 Drive。
- 上传直接从手机发送到 `www.googleapis.com`，不经过开发者服务器。
- Google Drive 上传会消耗网络流量和用户 Drive 容量；本地音频文件即使上传失败也会保留。
- 网页下载引擎是 yt-dlp；实际站点可用性与 403/验证策略仍依赖平台。

## 已知限制

- 在发布 APK 之前需要配置自己的 Google Cloud 项目才能实际启用 Drive OAuth；Android 客户端凭据由 Google 服务器按包名和 SHA-1 核验，不能用固定写在源码中的任意客户端 ID 代替。
- 后台上传由 WorkManager 调度，Android 可能根据网络、电池或系统限制延迟执行。它是自动排队上传，不承诺实时秒传。
- 在没有真机授权及 Drive API 项目的情况下，CI 编译成功不能视为 Google Drive 实际上传成功；必须在真机授权后实测。
