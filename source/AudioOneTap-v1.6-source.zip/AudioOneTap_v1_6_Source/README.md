# 音频直取 v1.6 – YouTube 下载音轨兼容修复

基于 v1.5，保持包名 `com.onec.audiodirect`、32 kbps AAC 默认压缩、20 秒转码无进展保护、180 秒总时限、跳过压缩和 Google Drive 保存按钮。

- 优先选择 YouTube HLS/m3u8 音轨（例如编号 234），避免优先强制 M4A/DASH 遇到的 403。
- 首选音轨下载异常时依次尝试 WebM/Opus 与其他播放器客户端，每次使用独立临时目录，避免坏的分片干扰新尝试。
- 显式配置已经内置的 QuickJS 执行文件路径以支持 yt-dlp 的 JS/EJS 挑战。
- 支持音频专用 MP4 文件后缀；错误日志汇总各轮下载失败原因。
- Bilibili 继续采用 bestaudio 下载策略。

**真实限制**：HTTP 403 可能由 YouTube 令牌、客户端限制、反爬等多种原因引起；三个方案只是改善兼容性，不保证每条视频下载成功。Android 真机成功需用户验证。
